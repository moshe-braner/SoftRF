#ifndef CDB_HOST_H
#define CDB_HOST_H

#include "cdb.h"

extern const cdb_options_t cdb_host_options;

#endif
